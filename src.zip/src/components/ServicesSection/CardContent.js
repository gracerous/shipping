import BalticAmerica from '../../images/cardsImg/BalticAmerica.jpg';
import BalticEast from '../../images/cardsImg/BalticEast.jpg';
import IndArab from '../../images/cardsImg/IndArab.jpg';
import IndChina from '../../images/cardsImg/IndChina.jpg';


export const CardsContentArr = [
  {
    id: 1,
    image: IndArab,
    title: 'India — Arabia',
    content: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s'
  },
  {
    id: 2,
    image: IndChina,
    title: 'Indo-Pacific — China',
    content: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s'
  },
  {
    id: 3,
    image: BalticAmerica,
    title: 'Baltic — America',
    content: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s'
  },
  {
    id: 4,
    image: BalticEast,
    title: 'Baltic — far East',
    content: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s'
  },
];
